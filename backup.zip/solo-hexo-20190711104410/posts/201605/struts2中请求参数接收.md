title: struts2中请求参数接收
date: '2016-05-27 02:50:27'
updated: '2016-05-27 02:50:27'
tags: [ssh, struts2, 请求参数]
permalink: /articles/2016/05/27/1558761219713.html
---
## 采用基本类型接受请求参数(get/post)
- 在Action类中定义与请求参数同名的属性，struts2便能自动接收请求参数并赋予给同名的属性。
- 请求路径：http://localhost:8080/action/xxx.action?id=66

		public class HelloWorldAction {
			private Integer id;
		
			public Integer getId() {
				return id;
			}
		
			public void setId(Integer id) {
				this.id = id;
			}
		}

## 采用复合类型接受请求参数
- 获取Bean属性的原理：
	- Struts2首先通过反射技术调用Person的默认构造器创建person的实例，然后再通过反射技术调用person中与请求参数同名的属性的setter方法，来获取请求参数数值。
- 请求路径：http://localhost:8080/action/xxx.action?person.id=1&person.name=zhangsan
- 实体bean

		public class Person {
			private String name;
			private Integer id;
		
			public String getName() {
				return name;
			}
		
			public void setName(String name) {
				this.name = name;
			}
		
			public Integer getId() {
				return id;
			}
		
			public void setId(Integer id) {
				this.id = id;
			}
		}

- HelloWorldAction类

		public class HelloWorldAction {
			private Person person;
		
			public Person getPerson() {
				return person;
			}
		
			public void setPerson(Person person) {
				this.person = person;
			}
		}


## 请求页面
	<body>
		<!-- get方法发送，如果是中文则会出现乱码，post不会，好像struts2.1.8有修正此问题
		基本类型get请求参数: http://localhost:8080/action/xxx.action?id=66
		复合类型get请求参数: http://localhost:8080/action/xxx.action?person.id=1&person.name=zhangsan-->
	
		<!-- post方法发送 -->
		<form action="<%=request.getContextPath()%>/xxx.action" method="post">
			<!-- 基本类型请求参数 -->
			id:<input type="text" name="id"><br/>
			name:<input type="text" name="name"><br/>

			<!-- 复合类型请求参数 -->
			person.id:<input type="text" name="person.id"><br/>
			person.name:<input type="text" name="person.name"><br/>
			<input type="submit" value="发送"/>
		</form>
	</body>

## 显示页面

	<body>
		<!-- 输出基本类型请求参数 -->
		id=${id}<br/>
		name=${name}<br/>

		<!-- 输出复合类型请求参数 -->
		person.id=${person.id }<br/>
		person.name=${person.name }<br/>
	</body>


	<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>