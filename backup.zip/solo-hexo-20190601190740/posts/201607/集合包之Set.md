title: 集合包之Set
date: '2016-07-04 00:22:08'
updated: '2016-07-04 00:22:08'
tags: [Java, Set, 分布式, 集合]
permalink: /articles/2016/07/04/1558761215232.html
---
## HashSet
- 实现：
	- 为了不允许元素重复，基于HashMap实现

- HashSet()
	- 创建HashMap对象


- add(E)
	- 调用map的put(O,O)，需要增加的元素作为map中的key，value传入一个已创建的final Object对象

<!--more-->

- remove(E)
	- 调用map的remove(E)

- contains(E)
	- 调用map.containsKey(E)

- iterator()
	- 调用map.keySet的iterator方法

> HashSet不支持get(int)获取指定位置的元素，只能自行通过iterator方法来获取

### HashSet要点
- 基于HashMap实现，无容量限制
- HashSet是非线程安全

## TreeSet

- 实现
	- 区别于HashSet支持排序，TreeSet基于TreeMap实现


- TreeSet()
	- 创建TreeMap对象

- add(E)
	- 调用TreeMap.put(O,O)

- remove(E)
	- 调用TreeMap.remove(E)

- iterator()
	- 调navigableKeySet的iterator方法

> TreeSet提供了排序方面的支持。例如，传入Comparator实现，descendingSet及descendingIterator实现

### TreeSet要点
- 基于TreeMap实现，支持排序
- TreeSet是非线程安全的



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>