title: TensorFlow 学习笔记一：初印象
date: '2019-04-25 09:22:42'
updated: '2019-04-25 09:22:42'
tags: [TensorFlow, 技术, 笔记]
permalink: /articles/2019/04/25/1556155362539.html
---
## 1. TensorFlow 产生的历史必然性

AI 历史上的三次大发展

- 1950s：人工智能

- 1980s：机器学习

- 2010s：深度学习

## 2. TensorFlow 与 Jeff Dean

- TensorFlow 创造者
- MapReduce 设计者

2012 年 Google Distbelief 第一代深度学习平台
- 谷歌搜索
- 谷歌广告
- 谷歌地图
- 谷歌街景
- 谷歌翻译
- YouTube

2015 年 Google TensorFlow 第二代深度学习平台（开源）
- Airbnb
- Google
- Intel
- Uber
- 京东
- 小米

### TensorFlow 的特点

- 灵活通用的深度学习库
- 端云结合的人工智能引擎
- 高性能的基础平台软件
- 跨平台的机器学习系统


## 3. TensorFlow 的应用场景

AlphaGo + TensorFlow 大胜人类围棋高手

无人银行，新老用户识别

行人检测

人脸检测

行为识别

身份证自动输入与人脸图像比较

OCR+自动化审核









