title: docker 常用命令
date: '2019-05-25 19:10:32'
updated: '2019-05-25 19:10:32'
tags: [技术, docker]
permalink: /articles/2019/05/25/1558782631908.html
---

## 常用命令

运行

```shell
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="solo" \
    --env JDBC_PASSWORD="solo" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=80 --server_scheme=http --server_host=yonglun.shop
```

关闭

```shell
docker stop 07e4f3b13f19
```

重启

```shell
docker restart 07e4f3b13f19	
```

删除

```shell
docker rm 07e4f3b13f19
```

查看

```shell
docker ps -n 5
```


docker 中 启动所有的容器命令
```shell
docker start $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

docker 中 关闭所有的容器命令
```shell
docker stop $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

<br />docker 中 删除所有的容器命令
```shell
docker rm $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

<br />docker中 删除所有的镜像
```shell
docker rmi $(docker images | awk '{print $3}' |tail -n +2)
```
tail -n +2 表示从第二行开始读取<br />
<br />

