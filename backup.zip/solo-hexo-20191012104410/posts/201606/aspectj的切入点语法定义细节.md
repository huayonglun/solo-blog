title: aspectj的切入点语法定义细节
date: '2016-06-08 19:20:12'
updated: '2016-06-08 19:20:12'
tags: [AOP, spring, ssh]
permalink: /articles/2016/06/08/1558761237377.html
---
### 表达式分析

expression=**"execution(\* com.liuyong666.service.impl.PersonServiceBean.\*(..))"**

- 第一个星号表示 拦截方法的返回值 为任意
	- 如果为 java.lang.String ，表示只拦截 返回值为String 的方法
	- 如果为 void ，则表示只拦截 返回值为 void 的方法
	- 如果为 !void ，则表示只拦截 返回值为 非void的方法

- 如果我们只拦截方法第一个参数为String,剩下的参数类型任意，则可以
　　expression="execution(java.lang.String com.liuyong666.service.impl.PersonServiceBean.*(java.lang.String,..))"


<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>