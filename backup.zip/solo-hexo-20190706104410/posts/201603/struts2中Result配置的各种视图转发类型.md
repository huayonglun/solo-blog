title: struts2中Result配置的各种视图转发类型
date: '2016-03-31 20:13:55'
updated: '2016-03-31 20:13:55'
tags: [Result配置, ssh, struts2, 视图转发类型]
permalink: /articles/2016/03/31/1558761217508.html
---
## 概述
	<action name="helloworld" class="com.liuyong666.action.HelloWorldAction">
    	<result name="success">/WEB-INF/page/hello.jsp</result>
	</action>
- result配置类似于struts1中的forward，但struts2中提供了多种结果类型，常用的类型有：
 +  dispatcher(默认值)、
 +  redirect(重定向) 、
 +  redirectAction 、 
 +  plainText
- 通过type属性值指定。 

## 结果类型
- redirect
 + 在result中还可以使用${属性名}表达式访问action中的属性，表达式里的属性名对应action中的属性。如下：

			<result type="redirect">/view.jsp?id=${id}</result>
- redirectAction
 + 如果重定向的action在同一个包下：

			<result type="redirectAction">helloworld</result>
 + 如果重定向的action在别的命名空间下：

			<result type="redirectAction">
    			<param name="actionName">helloworld</param>
    			<param name="namespace">/test</param>
			</result>
- plainText
 + 显示原始文件内容，例如：当我们需要原样显示jsp文件源代码的时候，我们可以使用此类型。

			<result name="source" type="plainText">
				<param name="location">/xxx.jsp</param>
    			<param name="charSet">UTF-8</param><!-- 指定读取文件的编码 -->
			</result>

## 全局结果集(Globle Result)
- 当有多个Action使用同一个结果集时，则可以使用全局结果集(Globle Result),如下：

		<global-results> <!-- 定义在包里 -->
    		<result name="mainpage">/main.jsp</result>
		</global-results>
- 多个包想使用同一个结果集，可以利用包的继承，实现代码重用。
 + 创建一个名叫"base"的package，让它继承"struts-default"
 + 该package里放入共用的global-results
 + 想要使用该结果集的包继承"base"



 <p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>