title: 使用 idea 快速搭建 Spring Boot 项目
date: '2019-05-12 21:44:31'
updated: '2019-05-12 21:44:31'
tags: [idea, Spring]
permalink: /articles/2019/05/12/1557668671594.html
---
![](https://img.hacpai.com/bing/20190216.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 一、新建项目

<a name="27LcS"></a>
### 1. File->New->Project

![屏幕快照 2019-05-12 下午9.35.42.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557668158069-3a1a8442-0b36-4fc7-a66c-e54d1a0f7e30.png#align=left&display=inline&height=395&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%889.35.42.png&originHeight=395&originWidth=766&size=177465&status=done&width=766)


<a name="9Ab4e"></a>
### 2. 找到 Spring Initialzr，点击 Next

![屏幕快照 2019-05-12 下午8.40.07.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557664828060-c9cf519a-0b9d-49ca-94f4-fea25c9e9331.png#align=left&display=inline&height=769&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%888.40.07.png&originHeight=769&originWidth=745&size=77749&status=done&width=745)

<a name="D7vXv"></a>
### 3. 修改项目信息，Next

![屏幕快照 2019-05-12 下午8.44.01.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557665081317-e6c91ebd-aa93-4024-945c-da1adc777b64.png#align=left&display=inline&height=771&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%888.44.01.png&originHeight=771&originWidth=744&size=59384&status=done&width=744)
<a name="o6GKd"></a>
## 
<a name="eWrZw"></a>
### 4. 选择 Web，Next

Lombok 可不加，我这里主要是减少 getter 和 setter 代码。


![屏幕快照 2019-05-12 下午8.45.20.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557665195158-7afe3450-c997-46ef-b7c5-3db7e1f41d65.png#align=left&display=inline&height=716&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%888.45.20.png&originHeight=716&originWidth=839&size=99270&status=done&width=839)
<a name="EhZU1"></a>
## 
<a name="q2dUq"></a>
### 5. 点击 Finish，完成项目创建

![屏幕快照 2019-05-12 下午8.47.13.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557665262876-519e09f2-cf55-4a9d-b92b-b6edc290787f.png#align=left&display=inline&height=766&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%888.47.13.png&originHeight=766&originWidth=839&size=37905&status=done&width=839)

<a name="y1hej"></a>
## 二、运行项目

<a name="XDsjA"></a>
### 1. 项目结构图

![屏幕快照 2019-05-12 下午9.13.01.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557666799105-ed2ec928-90b7-43ed-9815-1001f231be02.png#align=left&display=inline&height=530&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%889.13.01.png&originHeight=530&originWidth=980&size=115153&status=done&width=980)


<a name="lTFEP"></a>
### 2. 编写 Controller

```java
@RestController
public class HelloWorldController {


    @RequestMapping("/sayHello")
    public String sayHello() {

        return "Hello World!";
    }
}
```

效果如图：

![屏幕快照 2019-05-12 下午9.33.59.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557668058814-746316b1-2aa2-48e0-a589-69fd69061394.png#align=left&display=inline&height=494&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%889.33.59.png&originHeight=494&originWidth=984&size=132284&status=done&width=984)


<a name="Jcm3V"></a>
### 3. 启动项目

运行 DemoApplication 类启动项目，访问 [http://localhost:8080/sayHello](http://localhost:8080/sayHello) ，效果如图


![屏幕快照 2019-05-12 下午9.32.30.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557668008378-4bf4776b-2002-4843-bea1-2671d6fefdfc.png#align=left&display=inline&height=339&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%889.32.30.png&originHeight=339&originWidth=651&size=26056&status=done&width=651)
<a name="eDPSR"></a>
## 
<a name="isGYO"></a>
## 三、注意点

1. 生成的 Java 目录默认不是源代码模式，需要标记目录为源代码根目录。

![屏幕快照 2019-05-12 下午9.40.27.png](https://cdn.nlark.com/yuque/0/2019/png/292263/1557668446731-a56cde6c-f407-424c-ab27-3887f42007d6.png#align=left&display=inline&height=692&name=%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202019-05-12%20%E4%B8%8B%E5%8D%889.40.27.png&originHeight=692&originWidth=695&size=170146&status=done&width=695)
