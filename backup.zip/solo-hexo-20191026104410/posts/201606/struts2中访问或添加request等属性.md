title: struts2中访问或添加request等属性
date: '2016-06-11 02:50:27'
updated: '2016-06-11 02:50:27'
tags: [ssh, struts2]
permalink: /articles/2016/06/11/1558761220860.html
---
## 访问或添加request/session/application属性 

- 在struts2中获得request，session，application有3种方法
	1. 通过ServletActionContext类直接获取：此法比较常用
	2. 实现指定接口，有struts框架运行时注入：实现的接口是ServletRequestAware，ServletResponseAware，ServletContextAware，此方法不常用。
	3. 通过ActionContext类直接获取。此法较常用

### 方法一，通过ServletActionContext类直接获取：
	
	public class TestAction {
		 public String rsa(){
			  HttpServletRequest request = ServletActionContext.getRequest();
			  ServletContext servletContext =  ServletActionContext.getServletContext();
			  request.setAttribute("req", "请求范围属性");
			  request.getSession().setAttribute("ses", "会话范围属性");
			  servletContext.setAttribute("app", "应用范围属性");
			  return "message";
		 }
	}

### 方法三，通过ActionContext类直接获取：

	public class TestAction {
		 public String execute(){
			  ActionContext act = ActionContext.getContext();
			  act.getApplication().put("app", "应用范围");
			  act.getSession().put("ses", "session范围");
			  act.put("req","request范围");
			  act.put("names", Arrays.asList("小明","小敏","小李"));
			  return "message";
		 }
	}


### message.jsp页面

	<body>
		${applicationScope.app}<br/>
		${sessionScope.ses}<br/>
		${requestScope.req }<br/>
		<c:forEach items="${names }" var="name">
			  ${name } <br/>
		</c:forEach>
	</body>

### struts.xml配置文件

	<action name="user_*" class="com.liuyong666.action.TestAction" method="{1}">
	      <result name="message">/message.jsp</result>
	</action>

### 应用场景

- 仅仅是访问或添加属性，用ActionContext
- 需要额外获取路径等操作，用ServletActionContext

		HttpServletRequest request = ServletActionContext.getRequest();
		ServletContext servletContext =  ServletActionContext.getServletContext();
		servletContext.getRealPath("xxx");



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>