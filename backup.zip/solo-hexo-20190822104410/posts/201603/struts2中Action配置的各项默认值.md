title: struts2中Action配置的各项默认值
date: '2016-03-31 19:57:01'
updated: '2016-03-31 19:57:01'
tags: [Action配置, ssh, struts2]
permalink: /articles/2016/03/31/1558761216144.html
---
## Action中的各项默认值
- Action各项配置

      	<action name="helloworld" class="com.liuyong666.action.HelloWorldAction" method="execute" >
             <result name="success">/WEB-INF/page/hello.jsp</result>
     	</action>
- Action默认配置
      
		<action name="helloworld">
            <result>/WEB-INF/page/hello.jsp</result>
        </action>
- 默认值
 1. 如果没有为action指定class，默认是ActionSupport。
 2. 如果没有为action指定method，默认执行action中的execute() 方法。
 3. 如果没有指定result的name属性，默认值为success。



 <p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>