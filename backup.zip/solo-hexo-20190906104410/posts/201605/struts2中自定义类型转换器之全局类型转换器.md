title: struts2中自定义类型转换器之全局类型转换器
date: '2016-05-28 02:50:27'
updated: '2016-05-28 02:50:27'
tags: [ssh, struts2, 类型转换器]
permalink: /articles/2016/05/28/1558761219356.html
---
## 全局类型转换器
- 如果业务需求所有的日期都要转换，则可以使用全局类型转换器，只要在src根目录下面放置xwork-conversion.properties文件,并且properties文件中的内容为： 待转换的类型=类型转换器的全类名 
- 如：```Java.util.Date = com.liuyong666.type.converter.DateTypeConverter```。 
- 总体目录结构： 
![总体目录结构](http://i.imgur.com/jAQvOB5.png)


## 局部类型转换器和全局类型转换器的说明
- 局部类型转换器是对指定action指定属性进行转换。不管该action的该属性是数组还是List集合，该转换器的转换方法对该属性只转换一次，假设某个action有一个List<User>类型的属性users，那么局部类型转换器只调用一次convertValue方法，该方法吧users请求参数一次性地转换为一个List<User>集合对象。 
- 全局类型转换器会对所有action的特定类型进行转换。如果一个action的某个需要转换的属性是数组或集合，那么全局类型转换器将不是对该集合或数组整体进行转换，而是对该集合或数组的每一个属性进行转换。 



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>