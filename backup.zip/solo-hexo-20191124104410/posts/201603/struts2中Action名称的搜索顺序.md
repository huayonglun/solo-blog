title: struts2中Action名称的搜索顺序
date: '2016-03-31 19:34:46'
updated: '2016-03-31 19:34:46'
tags: [Action, ssh, struts2]
permalink: /articles/2016/03/31/1558761217205.html
---
## 搜索顺序
- 1.获得请求路径的URI，例如URL为：http://localhost:8080/struts2/path1/path2/path3/student.action
- 2.首先寻找namespace为/path1/path2/path3的package，
 - 如果不存在这个包，则执行步骤3；

			如果存在这个package，则在这个package中寻找名字为student的action，
			当在该package下寻找不到action时就会直接跑到默认namespace的package中寻找action
			(默认的命名空间为空字符串"")，
			如果在默认namespace的package中还找不到该action，页面会提示找不action。
- 3.寻找namespace为/path1/path2的package，
 - 如果不存在这个package，则执行步骤4；
 - 如果存在执行步骤2中的代码块中内容。
- 4.寻找namespace为/path1的package，
 - 如果不存在这个package，则执行步骤5；
 - 如果存在执行步骤2中的代码块中内容。
- 5.寻找namespace为/的package，
 - 如果存在这个package，则在这个package中寻找名字为student的action，
 - 当在package中找不到action或者不存在这个package时，都会去默认namespace的package里面寻找actin，
 - 如果还是找不到，页面会提示找不到action。



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>