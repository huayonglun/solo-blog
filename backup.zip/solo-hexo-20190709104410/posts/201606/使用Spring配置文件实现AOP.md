title: 使用Spring配置文件实现AOP
date: '2016-06-07 19:20:12'
updated: '2016-06-07 19:20:12'
tags: [AOP, spring, ssh]
permalink: /articles/2016/06/07/1558761238471.html
---
- 现在学习一下使用XML方式怎样来开发AOP应用。
- 如果使用XML方式开发AOP应用的话，我们就不再需要提供注解的配置，我们只需要一个普通的Java类对象

### MyInterceptor
	
	package com.liuyong666.service;
	
	import org.aspectj.lang.ProceedingJoinPoint;
	/**
	 * 切面
	 *
	 */
	public class MyInterceptor {	
		public void doAccessCheck() {
			System.out.println("前置通知");
		}
	
		public void doAfterReturning() {
			System.out.println("后置通知");
		}
		
		public void doAfter() {
			System.out.println("最终通知");
		}
		
		public void doAfterThrowing() {
			System.out.println("例外通知");
		}
		
		public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
			System.out.println("进入方法");
			Object result = pjp.proceed();
			System.out.println("退出方法");
			return result;
		}
		
	}

- 可以看到，在这个切面里面，这只是一个普普通通的Java类，里面没有任何的注解。

### PersonServiceBean
	
	package com.liuyong666.service.impl;
	import com.liuyong666.service.PersonService;
	
	public class PersonServiceBean implements PersonService {
		
	
	
		public void save(String name) {
	//		throw new RuntimeException("我是例外");
			System.out.println("我是save()方法！");
	
		}
	
		public void update(String name, Integer personid) {
			System.out.println("我是update()方法！");
		}
	
		public String getPersonName(Integer personid) {
			System.out.println("我是getPersonName()方法！");
			return "666";
		}
	
	}

- 如果我们采用基于XML方式来开发AOP应用的话，我们是要在配置文件中对切面进行配置的。现在看一下切面该如何配置

### 基于XML配置方式声明切面——beans.xml

    <aop:aspectj-autoproxy/> 
    
    <bean id="personService" class="com.liuyong666.service.impl.PersonServiceBean"/>

    <bean id="aspectbean" class="com.liuyong666.service.MyInterceptor"/>

    <aop:config>
    	<aop:aspect id="asp" ref="aspectbean">
        	<aop:pointcut id="mycut" expression="execution (* com.liuyong666.service.impl.PersonServiceBean.*(..))"/>
        	<aop:before pointcut-ref="mycut"  method="doAccessCheck"/>
        	<aop:after-returning pointcut-ref="mycut" method="doAfterReturning"/>
        	<aop:after pointcut-ref="mycut" method="doAfter"/>
        	<aop:after-throwing pointcut-ref="mycut" method="doAfterThrowing"/>
        	<aop:around pointcut-ref="mycut" method="doBasicProfiling"/>
    	</aop:aspect>
    </aop:config>

### 测试

	@Test
	public void interceptorTest(){
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		PersonService personService = (PersonService) context.getBean("personService");
		personService.save("hhh");
	}

### 结果
	
	前置通知
	进入方法
	我是save()方法！
	后置通知
	最终通知
	退出方法



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>