title: 配置Spring管理的bean的作用域
date: '2016-05-28 18:20:12'
updated: '2016-05-28 18:20:12'
tags: [bean, spring, ssh]
permalink: /articles/2016/05/28/1558761236633.html
---
## 配置Spring管理的bean的作用域

### .singleton
- 在每一个spring IoC容器中一个bean定义只有一个对象实例。默认情况下会在容器启动时初始化bean，但我们可以指定bean节点的lazy-init = "true"来延迟初始化bean，这时候，只有第一次获取bean才会初始化bean。如下：

		<bean id="persionService" 
			class="com.liuyong666.service.impl.PersionServiceBean"  
			lazy-init = "ture"/>


- 如果想对所有bean都应用延迟初始化，可以在节点beans设置default-lazy-init = "ture" ,如下：

		<beans default-lazy-init = "ture".../>

### .prototype
- 每次从容器获取bean都是新的对象。
- 在第一次获取bean时初始化

		<bean id="persionService" 
			class="com.liuyong666.service.impl.PersionServiceBean" 
			scope="prototype"/>

### .request

### .session

### .global session



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>