title: struts2中为应用指定多个struts配置文件
date: '2016-04-07 00:09:50'
updated: '2016-04-07 00:09:50'
tags: [struts2, 配置分解]
permalink: /articles/2016/04/07/1558761218644.html
---
## 概述
- 随着应用规模的增加，系统中Action的数量也会大量增加，导致struts.xml配置文件变得非常臃肿
- 为了避免struts.xml文件过于庞大、臃肿，提高Struts.xml文件的可读性，我们可以将一个struts.xml配置文件分解成多个配置文件
- 然后再struts.xml文件中包含其他配置文件

## 操作
- 通过<include\>元素指定多个配置文件 

		<struts>
			<include file="department.xml"/> 一个模块使用一个配置文件
			<include file="employee.xml"/>
		</struts>
- 通过这种方式，可以将struts2的Action按模块添加到多个配置文件中



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>