title: 本地远程连接 MySQL server
date: '2019-04-21 21:43:52'
updated: '2019-04-22 08:38:19'
tags: [MySql, 数据库]
permalink: /articles/2019/04/21/1555854232242.html
---


## 问题

MySql Server 出于安全方面考虑默认只允许本机(localhost, 127.0.0.1)来连接访问。如果想远程访问，需要额外做下操作。
<a name="d41d8cd9"></a>
## 
<a name="6be52fe8"></a>
## 配置修改

<a name="d78a3003"></a>
### 定位文件

/etc/mysql/mysql.conf.d/mysqld.cnf

<a name="cb0475ea"></a>
### 定位属性

```shell
skip-networking #注释掉 因为它是屏蔽掉一切TCP/IP连接 

bind-address = 127.0.0.1 #它和上一个选项是异曲同工，要想远程连接，也得注释掉 
```

<a name="fd285855"></a>
### 重启服务

```shell
/etc/init.d/mysql restart
```
<br />
<a name="2de89571"></a>
## 用户授权

```sql
-- 登录
mysql -u root -p

-- 切换数据库
use mysql；

-- 查询用户表命令
select  User,authentication_string,Host from user;

-- 新增用户密码，%代表所有主机，也可以具体到你的主机ip地址
CREATE USER 'solouser'@'%' identified BY 'solo@pwd';

-- 授权
GRANT ALL ON solo.* TO 'solouser'@'%'; 

-- 刷新权限，消除缓存的影响
FLUSH PRIVILEGES;
```



<a name="bf47488e"></a>
## 客户端登录

mac 端我使用 sequel-Pro，会发现可以正常访问。
