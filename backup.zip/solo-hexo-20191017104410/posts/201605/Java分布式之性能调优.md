title: Java分布式之性能调优
date: '2016-05-12 00:26:08'
updated: '2016-05-12 00:26:08'
tags: [Java, 分布式, 性能, 调优]
permalink: /articles/2016/05/12/1558761211213.html
---
![性能调化](http://i.imgur.com/maYlc2k.png)

![调优步骤](http://i.imgur.com/fFa1cKM.png)

## 寻找性能瓶颈

### CPU消耗分析
　　Linux中，CPU主要用于中断、内核以及用户进程的任务处理，优先级为中断>内核>用户进程

- 上下文切换
	- 每个CPU同一时间只能执行一个线程，Linux采用抢占式调度
	- 发生条件：
		- 到达执行时间
		- I/O阻塞
		- 高优先级线程要执行
		- Java中：
			- 文件I/O
			- 网络I/O
			- 锁等待
			- 线程sleep
	- 缺点：
		- 切换过多，造成内核占据较多的CPU使用，使应用的响应速度下降

- 运行队列
	- 每个CPU核都维护了一个可运行的线程队列。
	- 运行队列值越大，意味着线程会消耗越长的时间才能执行完

- 利用率
	- CPU在用户进程、内核、中断处理、IO等待以及空闲五个部分使用百分比
	- Linux中，top或pidstat可查看进程中线程的CPU消耗状况
		- top命令第3行为CPU信息
			- us表示用户进程百分比
			- sy表示内核进程
			- ni表示被nice命令改变优先级的任务所占的百分比
			- id表示CPU的空闲时间
			- wa表示在执行过程中等待IO
			- hi表示硬件中断
			- si表示软件中断
			- shift+h 可切换Tasks和Threads
		- pidstat 需要安装sysstat
			- pidstat 1 2 表示隔一秒输出，共输出2次
			- pidstat -p [pid] -t 1 5 某进程中线程的CPU消耗情况
			- tid为线程ID，该命令优点，可查看每个线程具体CPU利用率的状况
		- vmstat
			- 采样查看CPU的上下文切换，运行队列，利用率的具体信息

### 文件IO消耗分析
　　Linux在操作文件时，将数据放入文件缓存区，直到内存不够或系统要释放内存给用户进程使用。故free经常不多，cached用了很多。这是Linux提升文件IO速度的一种做法。

- 在这种做法下，如物理空闲内存够用，通常在Linux上只有写文件和第一次读取文件时会产生真正的文件IO
- pidstat 跟踪线程的文件IO的消耗
	- pid -d -t -p [pid] 1 100
	- KB_rd/s 每秒读取的KB数
	- KB_wr/s 每秒写入的KB数
- iostat 可查看各个设备的IO历史状况
	- Device ：设备卷标名或分区名
	- tps：每秒的IO请求数
	- KB_read/s
	- KB_wrtn/s
	- KB_read
	- KB_wrtn
- iostat -x xvda 3 5 定时采样查看IO消耗情况
	- r/s：每秒读的请求数
	- w/s：每秒写的请求数
	- await：平均每次IO操作的等待时间
	- avgqu-sz：等待请求的队列的平均长度
	- svctm：平均每次设备执行IO操作的时间
	- util：一秒之中有百分之几用于IO操作

- 使用iostat要关注iowait%
- Java应用造成IO消耗严重：
	- 主要是多个线程需要进行大量内容写入(例如频繁的日志写入)的动作
	- 磁盘设备本身的处理速度慢
	- 文件系统慢
	- 操作的文件本身已经很大

### 网络IO消耗分析
　　Linux中采用sar分析网络IO的消耗

- sar
	- sar -n ALL 1 2
	- 得到三部分：
		- 网卡上成功的接包和发包信息。rxpck/s,txpck/s,rxbyt/s,rxmcst/s
		- 网卡上失败的接包和发包信息。rxerr/s,txerr/s,rxdrop/s,txdrop/s
		- socket上的统计信息。tolsck,tcpsck,udpsck,rawsck

### 内存消耗分析
　　Java应用对内存的消耗主要在ＪＶＭ堆内存上。正式环境中，－Xms和-Xmx设为相同的值，避免运行期要不断申请内存。

- Java应用只有在**创建线程**和**使用Direct ByteBuffer**时才会操作JVM堆以外的内存。
- 堆外内存消耗主要关注swap的消耗和物理内存的消耗，都可以基于OS提供的命令来查看
- Linux用vmstat，sar，top，pidstat
- vmstat
	- 和内存相关的有memory下的swpd，free，buff，cache，swap下的si和so
	- swpd：虚拟内存已使用的部分,kb
	- free：空闲的物理内存
	- buff：缓冲的内存
	- cache：作为缓存的内存
	- si：每秒从disk读至内存的数据量
	- so：每秒从内存中写入disk的数据量
	- 物理内存消耗过多的原因:
		- JVM内存设置过大
		- 创建的Java线程过多
		- 通过Direct ByteBuffer往物理内存放置了过多的对象

- sar
	- sar -r 1 2
	- sar相比vmstat的好处是，可以查询历史状况以更加准确的分析趋势状况
	- 共同弱点：不能分析进程所占用的内存量

- top
	- top可查看进程所消耗的内存量
	- JVM已分配内存+Java应用所耗费的JVM以外的物理内存
	- top很难判断出Java进程消耗的内存中，有多少是属于JVM的，有多少是消耗JVM以外的内存

- pidstat
	- pidstat -r -p [pid] [interval] [times] 查看进程所消耗的内存量
	- 最佳内存消耗分析方法是：
		- 结合top或pidstat以及JVM内存分析工具来共同分析内存消耗

### 程序执行慢原因分析
　　资源消耗不多，但程序执行慢，多出现在访问量不是非常大的情况下

- 锁竞争激烈。例如：数据库连接池。
- 未充分使用硬件资源。例如：双核CPU但程序使用单线程。
- 数据量增长。例如：数据库单表100万记录增到1亿，读写速度下降。

## 调优
　　从硬件，操作系统，JVM，程序4个方面着手

### JVM调优
- 主要是内存管理方面的调优
	- 各个代的大小
	- GC策略
- 代大小的调优
	- 关键参数：
		- -Xms   
		- -Xmx：与-Xms设置相同的值，避免运行时不断扩展JVM内存空间
		- -Xmn：决定新生代空间的大小
		- -XX:SurvivorRatio：Eden，s0，s1的比率
		- -XX:MaxTenuringThreshold：控制对象在经历多少次Minor GC后才转入旧生代。这个值称为新生代存活周期。只在串行GC有效。
- 策略：
	- 避免新生代大小设置过小
		- 过小产生的现象：
			- Minor GC频繁
			- 可能导致Minor GC对象直接进入旧生代，若满，触发Full GC
		- 调整原则：
			- 尽可能放大新生代空间
			- 保证旧生代空间够用
	- 避免新生代设置过大
		- 过大产生现象：
			- 旧生代变小，Full GC频繁
			- Minor GC耗时大幅度增加
		- 推荐新生代占JVM Heap区大小的33%。
	- 避免Survivor区过大或过小
		- Survivor区域变大，意味着可以存储更多在minor GC后仍存活的对象，避免其进入旧生代
	- 合理设置新生代存活周期
		- -XX:MaxTenuringThreshold：默认15次

### 程序调优
　　根据资源的消耗情况

#### CPU消耗严重的解决办法
1. CPU us高的解决办法
	- 原因：
		- 执行线程无任何挂起动作，线程饿死
			- 解决办法：对这种线程的动作增加Thread.sleep()，以释放CPU的执行权，降低CPU的消耗
		- GC频繁
			- 解决办法：JVM调优，降低GC执行次数

2. CPU sy高的解决办法
	- 原因：
		- 线程的运行状态经常切换
	- 解决办法：
		- 减少线程数
		- 降低线程之间的锁竞争
	- Java应用中可采用协程(coroutine)来支撑更高的并发量，避免并发量上涨后造成CPU sy消耗严重，系统load迅速上涨和系统性能下降(框架Kilim)。

#### 文件消耗严重的解决办法
- 原因：
	- 多个线程在写大量的数据到同一文件
	- 导致文件很快变得很大
	- 从而写入速度越来越慢
	- 并造成各线程激烈争抢文件锁
- 解决办法：
	- 异步写文件。例如：写日志，log4j的AsyncAppender。
	- 批量读写
	- 限流。将文件IO消耗控制到一个能接受的范围。
	- 限制文件大小。超过最大值生成一个新的文件。例如log4j中RollingFileAppender的maxFileSize。
	- 缓冲区读取文件内容

#### 网络IO消耗严重的解决办法
- 原因：
	- 同时需要发送或接收的包太多
- 解决办法：
	- 限流。限制发送packet的频率

#### 内存消耗严重的情况
- 解决办法
	- 释放不必要的引用。例如，复用线程使用ThreadLocal，存放的对象如果未做主动释放的话则不会被GC。
	- 使用对象缓存池
	- 采用合理的缓存失效算法。放太多对象在缓存池中，会造成内存的严重消耗。控制缓存池大小的问题在于当到达缓存池最大容量后，如果要加入新的对象该如何处理：FIFO，LRU，LFU算法可控制缓存池中的对象数目。
	- 合理使用SoftReference和WeakReference。对于占据内存但又不是必须存在的对象，例如缓存对象，也可以基于SoftReference或WeakReference的方式进行缓存。

### 对于资源消耗不多，但程序执行慢的情况
- 原因：
	- 锁竞争激烈
	- 未充分发挥硬件资源

- 锁竞争激烈：
	- 线程多了后，锁竞争明显，线程容易处在等待锁的状况，从而导致性能下降，以及CPU sy上升。
	- 解决办法：
		- 使用并发包的类
		- 使用Treiber算法
		- 使用MichaelScott非阻塞队列算法(ConcurrentLinkedQueue)。以上两种算法都基于CAS以及AtomicReference
		- 尽可能少用锁。让锁最小化，只对互斥及原子操作的地方加锁
		- 拆分锁。把独占锁拆分成多把锁。读写锁拆分。ConcurrentHashMap默认拆分成16把锁。缺点：全局性质操作变复杂，比如size。
		- 去除读写操作的互斥锁。在修改时加锁，并复制对象进行修改，修改完毕后切换对象的引用，而读取时则不加锁，CopyOnWrite。

- 未充分使用硬件资源
	- 未充分使用CPU
		- 原因：
			- 并行处理的场景中未使用足够的线程
	- 未充分使用内存
		- 场景：
			- 数据缓存，耗时资源的缓存(数据库连接，网络连接)，页面片段的缓存
	



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>