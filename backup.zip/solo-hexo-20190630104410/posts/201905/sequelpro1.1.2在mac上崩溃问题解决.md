title: sequel-pro-1.1.2 在 mac 上崩溃问题解决
date: '2019-05-25 11:40:40'
updated: '2019-05-25 18:13:03'
tags: [MySQL]
permalink: /articles/2019/05/25/1558755640876.html
---

## 背景

在官网下了最新的 sequel-pro 用作 MySQL 的客户端，版本为 1.1.2，但在使用过程中经常会遇到崩溃，严重影响使用。

在选库和选表会有如下报错：

```shell
Sequel Pro encountered an unexpected error
```


## 问题原因

MySQL 版本 和 sequel-pro 版本不兼容。


```
mysql> select version() ;
+-----------+
| version() |
+-----------+
| 8.0.16    |
+-----------+
1 row in set (0.00 sec)
```


## 问题解决

使用 [test-builds](https://sequelpro.com/test-builds) 的版本。
