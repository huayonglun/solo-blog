title: struts2中动态方法调用和使用通配符定义action
date: '2016-04-07 00:31:11'
updated: '2016-04-07 00:31:11'
tags: [struts2, 动态方法, 通配符]
permalink: /articles/2016/04/07/1558761218946.html
---
## 动态方法调用
- 如果Action中存在多个方法时，我们可以使用!+方法名调用指定方法。

		public class HelloWorldAction{  
		    private String message;  
		    ....  
		    public String execute() throws Exception{  
		        this.message = "我的第一个struts2应用";  
		        return "success";  
		    }  
		      
		    public String other() throws Exception{  
		        this.message = "第二个方法";  
		        return "success";  
		    }  
		}  
- 假设访问上面action的URL路径为： /struts/test/helloworld.action要访问action的other() 方法，我们可以这样调用：
		
		/struts/test/helloworld!other.action

- 通常不建议使用动态方法调用，我们可以通过常量关闭动态方法调用。

		<constant name="struts.enable.DynamicMethodInvocation" value="false"/>

## 使用通配符定义action
- action代码同上，配置文件如下：

		<package name="liuyong666" namespace="/test" extends="struts-default">  
		    <action name="helloworld_*" class="com.liuyong666.action.HelloWorldAction" method="{1}">  
		        <result name="success">/WEB-INF/page/hello.jsp</result>  
		    </action>  
		</package>  
- 其中的helloworld\_\*中的下划线（_）并不是必须的
- 因为helloworld\_\*中只有一个通配符\*,所以method="{1}"
- 也可以是helloworld\_\*\_\*,则method="{1}_{2}"
- class和result中也可以使用通配符的值，如：

		class="com.liuyong666.action.{1}HelloWorldAction"
		－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－
		<result name="success">/WEB-INF/page/{1}hello.jsp</result>.

- 此时要访问action中的other()方法，可以通过这样的URL访问：

		/test/helloworld_other.action



<p></p>
--- 
<center>

<div align="center" style="color: rgb(212, 137, 88); font-size: x-large; font-family: 楷体; ">欢迎关注微信公众号，技术，思维，心理，带给你认知的全方位成长。<br/>


![](https://ws1.sinaimg.cn/large/006tNbRwgy1fvibc07tuqj30hs07q0u7.jpg)


你的关注，就是对我最大的肯定，我会努力产出的，我们一起成长~ 

本文由 **永伦的小屋** 原创。
转载请**注明作者及出处**,本文作者为 永伦的小屋。

</div>
</center>